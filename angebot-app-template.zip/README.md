# Angebot Web-App – Deployment-Anleitung

Siehe vollständige Anleitung im Haupt-README.md.
